// lib/models/product_model.dart

class ProductModel {
  final String id;
  final String name;
  final int price; 
  final String image;

  ProductModel({
    required this.id,
    required this.name,
    required this.price,
    required this.image,
  });

  // Penting untuk perbandingan objek dalam Map/Set Cubit
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ProductModel && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;

  // Metode toMap()
  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'name': name,
      'price': price,
      'image': image,
    };
  }

  // Metode fromMap()
  factory ProductModel.fromMap(Map<String, dynamic> map) {
    return ProductModel(
      id: map['id'] as String,
      name: map['name'] as String,
      // Pastikan konversi ke int karena price bertipe int
      price: map['price'] is String ? int.parse(map['price']) : map['price'] as int,
      image: map['image'] as String,
    );
  }
}