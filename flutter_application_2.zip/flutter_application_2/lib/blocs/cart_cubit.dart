// lib/blocs/cart_cubit.dart

import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/product_model.dart'; 

// State: Map<ProductModel, Kuantitas>
typedef CartState = Map<ProductModel, int>; 

class CartCubit extends Cubit<CartState> {
  CartCubit() : super({}); 

  // 1. Menambah produk / Meningkatkan kuantitas
  void addToCart(ProductModel product) {
    final currentCart = Map<ProductModel, int>.from(state);

    if (currentCart.containsKey(product)) {
      currentCart[product] = currentCart[product]! + 1;
    } else {
      currentCart[product] = 1;
    }
    emit(currentCart); 
  }

  // 2. Menghapus produk sepenuhnya
  void removeFromCart(ProductModel product) {
    final currentCart = Map<ProductModel, int>.from(state);
    currentCart.remove(product);
    emit(currentCart);
  }

  // 3. Mengubah jumlah item
  void updateQuantity(ProductModel product, int qty) {
    if (qty <= 0) {
      return removeFromCart(product);
    }
    
    final currentCart = Map<ProductModel, int>.from(state);
    if (currentCart.containsKey(product)) {
      currentCart[product] = qty;
      emit(currentCart);
    }
  }

  // 4. Menghitung total item (kuantitas)
  int getTotalItems() {
    return state.values.fold(0, (sum, qty) => sum + qty);
  }

  // 5. Menghitung total harga
  int getTotalPrice() {
    int total = 0;
    state.forEach((product, qty) {
      total += product.price * qty;
    });
    return total;
  }

  // --- Fungsi untuk Checkout ---
  void clearCart() {
    emit({}); 
  }

  // --- Fungsi untuk Bonus: Tombol "-" ---
  void decrementQuantity(ProductModel product) {
    final currentCart = Map<ProductModel, int>.from(state);

    if (currentCart.containsKey(product)) {
      final currentQty = currentCart[product]!;
      
      if (currentQty > 1) {
        currentCart[product] = currentQty - 1;
      } else {
        // Jika kuantitas 1, hapus
        currentCart.remove(product);
      }
    } 

    emit(currentCart);
  }
}