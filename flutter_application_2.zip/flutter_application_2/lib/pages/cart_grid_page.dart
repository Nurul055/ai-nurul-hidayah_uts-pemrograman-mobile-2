// lib/pages/cart_grid_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/product_model.dart';
import '../blocs/cart_cubit.dart';
import '../widgets/product_card.dart';
import 'cart_summary_page.dart';

// Data Dummy
final List<ProductModel> dummyProducts = [
  ProductModel(id: '1', name: 'Laptop lucu ', price: 15000000, image: 'laptop.jpeg'),
  ProductModel(id: '2', name: 'laptop ', price: 1200000, image: 'laptop1.jpeg'),
  ProductModel(id: '3', name: 'Mouse Wireless', price: 500000, image: 'mouse.jpeg'),
  ProductModel(id: '4', name: 'ipad "', price: 4500000, image: 'ipad.jpeg'),
];

class CartGridPage extends StatelessWidget {
  const CartGridPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Katalog Produk'),
        actions: [
          // BlocBuilder untuk tampilan real-time total item di keranjang
          BlocBuilder<CartCubit, CartState>(
            builder: (context, state) {
              final totalItems = context.read<CartCubit>().getTotalItems();
              return Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.shopping_cart),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const CartSummaryPage()),
                      );
                    },
                  ),
                  if (totalItems > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                        child: Text(
                          totalItems.toString(),
                          style: const TextStyle(color: Colors.white, fontSize: 10),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                ],
              );
            },
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(8.0),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, 
          childAspectRatio: 0.7, 
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemCount: dummyProducts.length,
        itemBuilder: (context, index) {
          return ProductCard(product: dummyProducts[index]);
        },
      ),
    );
  }
}