// lib/pages/cart_summary_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/cart_cubit.dart';
import '../models/product_model.dart'; 

class CartSummaryPage extends StatelessWidget {
  const CartSummaryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cartCubit = context.read<CartCubit>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ringkasan Keranjang'),
      ),
      body: BlocBuilder<CartCubit, CartState>(
        builder: (context, state) {
          final cartItems = state.entries.toList();
          final totalItems = cartCubit.getTotalItems();
          final totalPrice = cartCubit.getTotalPrice();

          if (cartItems.isEmpty) {
            return const Center(
              child: Text('Keranjang Anda kosong.'),
            );
          }

          return Column(
            children: [
              // Daftar Produk (dengan tombol + dan - Bonus)
              Expanded(
                child: ListView.builder(
                  itemCount: cartItems.length,
                  itemBuilder: (context, index) {
                    final product = cartItems[index].key;
                    final quantity = cartItems[index].value;
                    
                    return _CartItemTile(
                      product: product, 
                      quantity: quantity,
                      cartCubit: cartCubit, 
                    );
                  },
                ),
              ),
              
              // Area Ringkasan Total
              _SummaryArea(totalItems: totalItems, totalPrice: totalPrice),
              
              // Tombol Checkout (Memanggil clearCart)
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: () {
                    cartCubit.clearCart();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Checkout Berhasil!')),
                    );
                    Navigator.pop(context); 
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50),
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Checkout', style: TextStyle(fontSize: 18)),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// Widget untuk item di keranjang (Implementasi Bonus: + dan -)
class _CartItemTile extends StatelessWidget {
  final ProductModel product;
  final int quantity;
  final CartCubit cartCubit;

  const _CartItemTile({
    super.key,
    required this.product,
    required this.quantity,
    required this.cartCubit,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        width: 50, height: 50, color: Colors.blue[100], 
        alignment: Alignment.center,
        child: Text(product.name[0]),
      ),
      title: Text(product.name),
      subtitle: Text('Rp ${product.price}'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Tombol "-" (Bonus)
          IconButton(
            icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
            onPressed: () {
              cartCubit.decrementQuantity(product);
            },
          ),
          // Kuantitas
          SizedBox(
            width: 24,
            child: Text(quantity.toString(), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          // Tombol "+" (Bonus)
          IconButton(
            icon: const Icon(Icons.add_circle_outline, color: Colors.green),
            onPressed: () {
              cartCubit.addToCart(product);
            },
          ),
        ],
      ),
    );
  }
}

// Widget untuk menampilkan Ringkasan Total
class _SummaryArea extends StatelessWidget {
  final int totalItems;
  final int totalPrice;

  const _SummaryArea({super.key, required this.totalItems, required this.totalPrice});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade300, width: 1.0))
      ),
      child: Column(
        children: [
          _buildSummaryRow('Total Item:', totalItems.toString()),
          const SizedBox(height: 8),
          _buildSummaryRow('Total Harga:', 'Rp ${totalPrice.toString()}', isTotal: true),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String title, String value, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: TextStyle(fontWeight: isTotal ? FontWeight.bold : FontWeight.w500)),
        Text(value, style: TextStyle(fontWeight: FontWeight.bold, color: isTotal ? Colors.red : Colors.black)),
      ],
    );
  }
}