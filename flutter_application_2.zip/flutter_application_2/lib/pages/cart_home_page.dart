import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/cart_cubit.dart';
import 'cart_summary_page.dart'; 

class CartSummaryPage extends StatelessWidget {
  const CartSummaryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cartCubit = context.read<CartCubit>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ringkasan Keranjang'),
        backgroundColor: Colors.blueGrey,
        foregroundColor: Colors.white,
      ),
      // BlocBuilder akan rebuild seluruh layar setiap kali CartState berubah
      body: BlocBuilder<CartCubit, CartState>(
        builder: (context, state) {
          final cartItems = state.entries.toList();
          final totalItems = cartCubit.getTotalItems();
          final totalPrice = cartCubit.getTotalPrice();

          if (cartItems.isEmpty) {
            return const Center(
              child: Text('Keranjang Anda kosong.'),
            );
          }

          return Column(
            children: [
              // --- Daftar Produk di Keranjang ---
              Expanded(
                child: ListView.builder(
                  itemCount: cartItems.length,
                  itemBuilder: (context, index) {
                    final product = cartItems[index].key;
                    final quantity = cartItems[index].value;
                    
                    // Menggunakan widget terpisah untuk item keranjang (termasuk tombol Bonus)
                    return _CartItemTile(
                      product: product, 
                      quantity: quantity,
                      cartCubit: cartCubit, 
                    );
                  },
                ),
              ),
              
              // --- Area Ringkasan Total ---
              _SummaryArea(totalItems: totalItems, totalPrice: totalPrice),
              
              // --- Tombol Checkout ---
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: () {
                    // Memanggil fungsi clearCart() untuk mengosongkan keranjang
                    cartCubit.clearCart();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Checkout Berhasil! Keranjang dikosongkan.')),
                    );
                    Navigator.pop(context); 
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50),
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text(
                    'Checkout',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// Widget untuk menampilkan Ringkasan Total
class _SummaryArea extends StatelessWidget {
  final int totalItems;
  final int totalPrice;

  const _SummaryArea({
    required this.totalItems,
    required this.totalPrice,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade300, width: 1.0))
      ),
      child: Column(
        children: [
          _buildSummaryRow('Total Item:', totalItems.toString(), isTotal: false),
          const SizedBox(height: 8),
          _buildSummaryRow('Total Harga:', 'Rp ${totalPrice.toString()}', isTotal: true),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String title, String value, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.w500,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: isTotal ? Colors.red : Colors.black,
          ),
        ),
      ],
    );
  }
}